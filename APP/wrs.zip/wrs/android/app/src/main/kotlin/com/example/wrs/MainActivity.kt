package com.example.wrs

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
